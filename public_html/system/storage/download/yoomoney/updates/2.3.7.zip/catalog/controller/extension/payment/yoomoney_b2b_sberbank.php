<?php

use YooKassa\Model\CurrencyCode;
use YooKassa\Model\Payment;
use YooKassa\Model\PaymentData\B2b\Sberbank\VatData;
use YooKassa\Model\PaymentData\B2b\Sberbank\VatDataType;
use YooKassa\Model\PaymentData\PaymentDataB2bSberbank;

require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'yoomoney.php';

class ControllerExtensionPaymentYoomoneyB2bSberbank extends ControllerExtensionPaymentYoomoney
{
    /**
     * @var ModelExtensionPaymentYoomoneyB2bSberbank
     */
    private $_model;

    /**
     * Экшен генерирующий страницу оплаты с помощью ЮMoney
     *
     * @return string
     */
    public function index()
    {
        $this->load->language($this->getPrefix().'payment/'.self::MODULE_NAME);
        $this->document->setTitle($this->language->get('heading_title'));

        $model = $this->getModel()->getPaymentModel();
        if ($model === null) {
            $this->failure('YooKassa module disabled');
        }

        if ($model->getMinPaymentAmount() > 0 && $model->getMinPaymentAmount() > $this->cart->getSubTotal()) {
            $this->failure(sprintf($this->language->get('error_minimum'),
                $this->currency->format($model->getMinPaymentAmount(), $this->session->data['currency'])));
        }

        $this->load->model('checkout/order');
        $orderInfo = $this->model_checkout_order->getOrder($this->session->data['order_id']);
        $template  = $this->applyTemplateVariables($this, $data, $orderInfo);

        $data['language'] = $this->language;
        $shopId           = $this->config->get('yoomoney_kassa_shop_id');

        $amount         = sprintf(
            '%.2f',
            $this->currency->convert($orderInfo['total'], $orderInfo['currency_code'], 'RUB')
        );
        $data['shopId'] = $shopId;
        $data['sum']    = $amount;
        if ($this->getModel()->getKassaModel()->isEnabled()) {

        }

        $data['fullView'] = false;

        $data['column_left']    = $this->load->controller('common/column_left');
        $data['column_right']   = $this->load->controller('common/column_right');
        $data['content_top']    = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer']         = $this->load->controller('common/footer');
        $data['header']         = $this->load->controller('common/header');
        $this->getModel()->log('info', $this->getTemplatePath($template));

        return $this->load->view($this->getTemplatePath($template), $data);
    }

    /**
     * @param array $templateData
     * @param $controller
     *
     * @return string
     */
    public function applyTemplateVariables($controller, &$templateData, $orderInfo)
    {
        $templateData['kassa']           = $this->getModel()->getKassaModel();
        $templateData['image_base_path'] = HTTPS_SERVER.'image/catalog/payment/yoomoney';
        $templateData['validate_url']    = $controller->url->link($this->getPrefix().'payment/yoomoney_b2b_sberbank/create',
            '', true);

        $templateData['amount']         = $orderInfo['total'];
        $templateData['comment']        = $orderInfo['comment'];
        $templateData['orderId']        = $orderInfo['order_id'];
        $templateData['customerNumber'] = trim($orderInfo['order_id'].' '.$orderInfo['email']);
        $templateData['orderText']      = $orderInfo['comment'];

        return 'payment/yoomoney/kassa_form_b2b';
    }

    /**
     * Экшен проведения платежа, вызываемый после подтверждения заказа пользователем
     */
    public function create()
    {
        $kassa = $this->getModel()->getKassaModel();
        ob_start();
        if (!$kassa->isEnabled()) {
            $this->jsonError('YooKassa module disabled');
        }
        if (!isset($this->session->data['order_id'])) {
            $this->jsonError('Cart is empty');
        }

        $paymentMethod = $this->request->get['paymentType'];
        if (!$kassa->getB2bSberbankEnabled() || $paymentMethod != YooKassa\Model\PaymentMethodType::B2B_SBERBANK) {
            $this->jsonError('Invalid payment method');
        }

        $orderId = $this->session->data['order_id'];
        $this->getModel()->log('info', 'Создание платежа для заказа №'.$orderId);
        if (!isset($this->request->get['paymentType'])) {
            $this->jsonError('Payment method not specified');
        }

        $payment = $this->createPayment($orderId);

        if ($payment === null) {
            $this->jsonError('Платеж не прошел. Попробуйте еще или выберите другой способ оплаты');
        } elseif ($payment->getStatus() === \YooKassa\Model\PaymentStatus::CANCELED) {
            $this->jsonError('Платеж не прошел. Попробуйте еще или выберите другой способ оплаты');
        }
        $result       = array(
            'success'  => true,
            'redirect' => $this->url->link('checkout/success', '', true),
        );
        $confirmation = $payment->getConfirmation();
        if ($confirmation !== null && $confirmation->getType() === \YooKassa\Model\ConfirmationType::REDIRECT) {
            $result['redirect'] = $confirmation->getConfirmationUrl();
        }

        if ($kassa->getCreateOrderBeforeRedirect()) {
            $this->getModel()->log('info', 'Confirm order#'.$orderId.' after payment creation');
            $this->getModel()->confirmOrder($orderId, $payment);
        }
        if ($kassa->getClearCartBeforeRedirect()) {
            $this->getModel()->log('info', 'Clear order#'.$orderId.' cart after payment creation');
            $this->cart->clear();
        }

        $output = ob_get_clean();
        if (!empty($output)) {
            $this->getModel()->log('warning', 'Non empty buffer: '.$output);
        }

        echo json_encode($result);
        exit();
    }

    /**
     * @param $orderId
     *
     * @return null
     */
    public function createPayment($orderId)
    {
        $this->load->model('checkout/order');
        $orderInfo = $this->model_checkout_order->getOrder($orderId);
        if (empty($orderInfo)) {
            return null;
        }

        $returnUrl = htmlspecialchars_decode(
            $this->url->link('extension/payment/yoomoney/confirm', 'order_id='.$orderId, true)
        );

        $amount = $orderInfo['total'];
        if ($orderInfo['currency_code'] !== 'RUB') {
            $amount = $this->currency->convert($amount, $orderInfo['currency_code'], 'RUB');
        }

        try {
            $builder     = \YooKassa\Request\Payments\CreatePaymentRequest::builder();
            $description = $this->generatePaymentPurpose($orderInfo);
            $builder->setAmount($amount)
                    ->setCurrency('RUB')
                    ->setDescription($description)
                    ->setClientIp($_SERVER['REMOTE_ADDR'])
                    ->setCapture(true)
                    ->setMetadata(array(
                        'order_id'       => $orderId,
                        'cms_name'       => 'yoo_opencart2',
                        'module_version' => self::MODULE_VERSION,
                    ));

            $confirmation = array(
                'type'      => \YooKassa\Model\ConfirmationType::REDIRECT,
                'returnUrl' => $returnUrl,
            );

            $paymentMethodData = new PaymentDataB2bSberbank();

            $paymentPurpose = $this->generatePaymentPurpose($orderInfo);

            try {
                $vatTypeAndRate = $this->calculateVatTypeAndRate($orderInfo);
            } catch (Exception $e) {
                $this->jsonError($this->language->get('b2b_tax_rates_error'));
            }

            if ($vatTypeAndRate['vatType'] === VatDataType::CALCULATED) {
                $vatRate      = $vatTypeAndRate['vatRate'];
                $vatSumAmount = $this->currency->format($orderInfo['total'],
                        $orderInfo['currency_code'], $orderInfo['currency_value'],
                        false) * $vatTypeAndRate['vatRate'] / 100;
                $vatData      = new VatData(
                    VatDataType::CALCULATED,
                    $vatRate,
                    ['value' => round($vatSumAmount, 2), 'currency' => CurrencyCode::RUB]
                );
            } else {
                $vatData = new VatData(VatDataType::UNTAXED);
            }

            $paymentMethodData->setPaymentPurpose($paymentPurpose);
            $paymentMethodData->setVatData($vatData);


            $builder->setPaymentMethodData($paymentMethodData);

            $builder->setConfirmation($confirmation);

            $request = $builder->build();

        } catch (InvalidArgumentException $e) {
            $this->getModel()->log('error', 'Failed to create create payment request: '.$e->getMessage());

            return null;
        }

        try {
            $payment = $this->getModel()->getClient()->createPayment($request);
        } catch (Exception $e) {
            $this->getModel()->log('error', 'Failed to create payment: '.$e->getMessage());
            $payment = null;
        }
        if ($payment !== null) {
            $this->insertPayment($payment, $orderId);
        }

        return $payment;
    }

    /**
     * @param $order
     *
     * @return array
     * @throws Exception
     */
    private function calculateVatTypeAndRate($order)
    {
        $this->load->model('account/order');
        $this->load->model('catalog/product');

        $kassa = $this->getModel()->getKassaModel();

        $taxRates = $kassa->getB2bTaxRates();

        $usedTaxes = array();

        $products = $this->model_account_order->getOrderProducts($order['order_id']);
        foreach ($products as $product) {
            $product_info = $this->model_catalog_product->getProduct($product["product_id"]);
            $usedTax      = isset($product_info['tax_class_id']) && isset($taxRates[$product_info['tax_class_id']])
                            ? $taxRates[$product_info['tax_class_id']]
                            : $kassa->getB2bSberbankDefaultTaxRate();
            $usedTaxes[]  = $usedTax;
        }
        $usedTaxes = array_unique($usedTaxes);

        if (count($usedTaxes) !== 1) {
            throw new Exception();
        }

        $vatType = reset($usedTaxes);
        if ($vatType === VatDataType::UNTAXED) {
            return array(
                'vatType' => $vatType,
            );
        }

        return array(
            'vatType' => VatDataType::CALCULATED,
            'vatRate' => $vatType,
        );
    }

    /**
     * @param $orderInfo
     *
     * @return string
     */
    private function generatePaymentPurpose($orderInfo)
    {
        $this->load->language($this->getPrefix().'payment/yoomoney');

        $descriptionTemplate = $this->getModel()->getKassaModel()->getB2bSberbankPaymentPurpose();
        if (!$descriptionTemplate) {
            $descriptionTemplate = $this->language->get('kassa_default_payment_description');
        }
        $replace = array();
        foreach ($orderInfo as $key => $value) {
            if (is_scalar($value)) {
                $replace['%'.$key.'%'] = $value;
            }
        }
        $description = strtr($descriptionTemplate, $replace);

        $description = (string)mb_substr($description, 0, 210);

        return $description;
    }

    /**
     * @param \YooKassa\Model\PaymentInterface $payment
     * @param int $orderId
     */
    private function insertPayment($payment, $orderId)
    {
        $paymentMethodId = '';
        if ($payment->getPaymentMethod() !== null) {
            $paymentMethodId = $payment->getPaymentMethod()->getId();
        }
        $sql = 'INSERT INTO `'.DB_PREFIX.'yoomoney_payment` (`order_id`, `payment_id`, `status`, `amount`, '
               .'`currency`, `payment_method_id`, `paid`, `created_at`) VALUES ('
               .(int)$orderId.','
               ."'".$this->db->escape($payment->getId())."',"
               ."'".$this->db->escape($payment->getStatus())."',"
               ."'".$this->db->escape($payment->getAmount()->getValue())."',"
               ."'".$this->db->escape($payment->getAmount()->getCurrency())."',"
               ."'".$this->db->escape($paymentMethodId)."',"
               ."'".($payment->getPaid() ? 'Y' : 'N')."',"
               ."'".$this->db->escape($payment->getCreatedAt()->format('Y-m-d H:i:s'))."'"
               .') ON DUPLICATE KEY UPDATE '
               .'`payment_id` = VALUES(`payment_id`),'
               .'`status` = VALUES(`status`),'
               .'`amount` = VALUES(`amount`),'
               .'`currency` = VALUES(`currency`),'
               .'`payment_method_id` = VALUES(`payment_method_id`),'
               .'`paid` = VALUES(`paid`),'
               .'`created_at` = VALUES(`created_at`)';
        $this->db->query($sql);
    }

    /**
     * @return ModelExtensionPaymentYoomoneyB2bSberbank
     */
    public function getModel()
    {
        if ($this->_model === null) {
            $this->load->model($this->getPrefix().'payment/yoomoney_b2b_sberbank');
            if ($this->getPrefix() === '') {
                $this->_model = $this->model_payment_yoomoney_b2b_sberbank;
            } else {
                $this->_model = $this->model_extension_payment_yoomoney_b2b_sberbank;
            }
        }

        return $this->_model;
    }
}

class ControllerPaymentYoomoneyB2bSberbank extends ControllerExtensionPaymentYoomoneyB2bSberbank
{
}
