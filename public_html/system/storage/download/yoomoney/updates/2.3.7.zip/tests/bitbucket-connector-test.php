<?php

use YooMoney\Updater\Archive\RestoreZip;

$path = '../admin/model/extension/payment/yoomoney/Updater/';
require_once $path.'BitbucketConnector.php';
require_once $path.'ProjectStructure/EntryInterface.php';
require_once $path.'ProjectStructure/DirectoryEntryInterface.php';
require_once $path.'ProjectStructure/FileEntryInterface.php';
require_once $path.'ProjectStructure/AbstractEntry.php';
require_once $path.'ProjectStructure/DirectoryEntry.php';
require_once $path.'ProjectStructure/FileEntry.php';
require_once $path.'ProjectStructure/ProjectStructureReader.php';
require_once $path.'ProjectStructure/ProjectStructureWriter.php';
require_once $path.'ProjectStructure/RootDirectory.php';
require_once $path.'Archive/BackupZip.php';
require_once $path.'Archive/RestoreZip.php';

$repository = 'cms/repos/cms-opencart2';

$connector = new BitbucketConnector();
$latest = $connector->getLatestRelease($repository);
echo $latest . "\n";

$currentVersion = '2.2.4';
$oldChangeLog = __DIR__.'/CHANGELOG-'.$currentVersion.'.md';
$newChangeLog = __DIR__.'/CHANGELOG-'.$latest.'.md';

$fileName = $connector->downloadLatestChangeLog($repository, __DIR__, 'CHANGELOG.md', 'release/v'.$currentVersion);
echo $fileName . "\n";
if (!empty($fileName)) {

    rename(__DIR__.'/'.$fileName, $oldChangeLog);
}

$fileName = $connector->downloadLatestChangeLog($repository, __DIR__);
echo $fileName . "\n";
if (!empty($fileName)) {
    rename(__DIR__.'/'.$fileName, $newChangeLog);
}

$fileName  = $connector->downloadRelease($repository, $latest, __DIR__);
if (empty($fileName)) {
    echo "updater_log_text_load_failed\n";
} else {
    echo $fileName . "\n";
}

try {
    $sourceDirectory = __DIR__ . '/restore';
    $archive         = new RestoreZip($fileName);
    $archive->restore('opencart-2.2.0.map', $sourceDirectory);
} catch (Exception $e) {
    echo 'error ', $e->getMessage() . "\n";
    if ($e->getPrevious() !== null) {
        echo 'error ' . $e->getPrevious()->getMessage() . "\n";
    }
}
$result = '';
if (file_exists($newChangeLog)) {
    $result = $connector->diffChangeLog($oldChangeLog, $newChangeLog);
}
echo 'result: ' . $result;